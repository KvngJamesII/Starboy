
import express from 'express';
import { Handler } from '@netlify/functions';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import * as admin from 'firebase-admin';
import { hashPassword, verifyPassword } from './auth';

const app = express();

// Initialize Firebase Admin if not already initialized
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n')
    })
  });
}

const db = admin.firestore();

// Enable CORS
app.use(cors({
  origin: true,
  credentials: true
}));

// Parse JSON bodies
app.use(express.json());

// Signup endpoint
app.post('/signup', async (req, res) => {
  try {
    const schema = z.object({
      email: z.string().email(),
      password: z.string().min(6),
      referredBy: z.string().optional()
    });

    const { email, password, referredBy } = schema.parse(req.body);
    const hashedPassword = await hashPassword(password);

    const existingUser = await db.collection('users').where('email', '==', email).get();

    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const userRef = await db.collection('users').add({
      email,
      password: hashedPassword,
      referredBy: referredBy || null,
      createdAt: new Date()
    });
    const user = { id: userRef.id, email };

    const token = jwt.sign({ userId: user[0].id }, process.env.JWT_SECRET || 'secret');

    return res.status(200).json({ 
      success: true,
      token,
      user: { id: user[0].id, email: user[0].email }
    });
  } catch (error) {
    console.error('Signup error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Login endpoint
app.post('/login', async (req, res) => {
  try {
    const schema = z.object({
      email: z.string().email(),
      password: z.string()
    });

    const { email, password } = schema.parse(req.body);

    const user = await db.query.users.findFirst({
      where: (users) => users.email.equals(email)
    });

    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const isValidPassword = await verifyPassword(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET || 'secret');

    return res.status(200).json({ 
      success: true,
      token,
      user: { id: user.id, email: user.email }
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

export const handler: Handler = async (event, context) => {
  const path = event.path.replace('/.netlify/functions/api/', '/');
  
  return new Promise((resolve, reject) => {
    const req = {
      ...event,
      path,
      body: event.body ? JSON.parse(event.body) : undefined
    };

    const res = {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: '',
      status(code) {
        this.statusCode = code;
        return this;
      },
      json(data) {
        this.body = JSON.stringify(data);
        resolve(this);
        return this;
      }
    };

    app(req, res, (err) => {
      if (err) {
        console.error('Error:', err);
        resolve({
          statusCode: 500,
          body: JSON.stringify({ error: 'Internal Server Error' })
        });
      }
    });
  });
};
