const express = require('express');
const serverless = require('serverless-http');
const cors = require('cors');
const { storage } = require('../../server/storage');

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.post('/auth/register', async (req, res) => {
  try {
    const { email, password, referralCode, referredBy } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    const user = await storage.createUser({ email, password, referralCode, referredBy });
    return res.status(200).json({ success: true, user });
  } catch (error) {
    console.error('Registration error:', error);
    return res.status(400).json({ error: error.message || 'Registration failed' });
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await storage.getUserByEmail(email);
    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    res.json(user);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Protected routes
app.get('/tasks', async (req, res) => {
  const tasks = await storage.getAvailableTasks();
  res.json(tasks);
});

app.post('/tasks', async (req, res) => {
  try {
    const task = await storage.createTask(req.body);
    res.json(task);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = app;
